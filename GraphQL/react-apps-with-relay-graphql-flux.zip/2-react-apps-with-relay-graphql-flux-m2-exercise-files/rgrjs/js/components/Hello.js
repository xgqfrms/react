import React from "react";

export default class Hello extends React.Component {
  render() {
    return <h3>This is cool!</h3>;
  }
}
