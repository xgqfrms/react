import Flux from "flux";

let AppDispatcher = new Flux.Dispatcher();

export default AppDispatcher;
