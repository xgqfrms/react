export let ActionTypes = {
  RECEIVE_LINKS: 'RECEIVE_LINKS'
};
