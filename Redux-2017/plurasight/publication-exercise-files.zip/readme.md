To run:
1. Install Node and Git
2. npm install
3. npm start

Having issues? Please post on the course discussion, and check the course issues here: 
https://github.com/coryhouse/ps-react/blob/master/README.md#issues

-----------------

Interested in getting started quickly, or getting professional guidance on your next React project? I offer both in-person and virtual consulting and training, customized for your needs. Reach me at Reactjsconsulting.com.
